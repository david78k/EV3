package lejos.ev3.tools;

public enum EV3ConnectionState {
	CONNECTED,
	DISCONNECTED,
	UNKNOWN;
}
